<?php
echo ("Hubo un error en el registro. Presiona el boton de olvidar la red e intentalo de nuevo.");
 ?>
