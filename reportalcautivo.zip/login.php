<?php

print_r($_POST);

$username='chillispot';
$password='chillispot';
$challenge=$_POST['challenge'];
$redir=$_POST['userurl'];
//
$enc_pwd=return_new_pwd($password,$challenge);
$server_ip='192.168.3.1';
$port='3990';
//$dir          = '/json/logon';
$dir            = '/logon';
$target     = "http://$server_ip".':'.$port.$dir."?username=$username&password=$enc_pwd&userurl=$redir";

//de prueba
// $target     = "http://$server_ip".':'.$port.$dir."?username=$username&password=$enc_pwd&userurl=$redir";

header("Location: $target");
//
function return_new_pwd($pwd,$challenge){
              $uamsecret = 'secretodeamor';    //Must be the same phrase coova chilli uses
              $hex_chal  = pack('H32', $challenge);
              $newchal    = pack('H*', md5($hex_chal.$uamsecret));    //Add it to with $uamsecret (shared between chilli an this script)
              $response   = md5("\0" . $pwd . $newchal);              //md5 the lot
              $newpwd     = pack('a32', $pwd);                //pack again
              $password   = implode ('', unpack('H32', ($newpwd ^ $newchal))); //unpack again
              return $password;
         }

?>
