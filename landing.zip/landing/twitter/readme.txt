Hi.
This is a free script and you can use it anywhere.

If you find this script useful do share this with your friends.
---------------------------------------------------------------
website: http://www.PHPHive.info
facebook: https://www.facebook.com/pages/PHPHive/1548210492057258
