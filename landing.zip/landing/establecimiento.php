<div id="logo_restaurante">
			<img src="restaurante/logo.png" class="logo">
		</div><!--logo_restaurante-->
		<div id="foto_restaurante">
			<img src="restaurante/foto.png" class="foto">
		</div><!--foto_restaurante-->